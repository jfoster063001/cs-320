package contact;

import org.junit.Assert;
import org.junit.Test;


public class ContactTest {

	@Test
	public void testContacttrue() {
		Contact c = new Contact("","","","","");
		Assert.assertTrue(c.setContactID("123456789"));
		Assert.assertTrue(c.setPhoneNumber("8161234567"));
		Assert.assertTrue(c.setFirstName("Joe"));
		Assert.assertTrue(c.setLastName("Mama"));
		Assert.assertTrue(c.setAddress("123 home"));
	}
	@Test
	public void testIdfalse() {
		Contact c = new Contact("","","","","");
		Assert.assertFalse(c.setContactID("12345678901"));
		Assert.assertTrue(c.setPhoneNumber("8161234567"));
		Assert.assertTrue(c.setFirstName("Joe"));
		Assert.assertTrue(c.setLastName("Mama"));
		Assert.assertTrue(c.setAddress("123 home"));
	}
	@Test
	public void testnumberfalse() {
		Contact c = new Contact("","","","","");
		Assert.assertTrue(c.setContactID("123456789"));
		Assert.assertFalse(c.setPhoneNumber("81612345"));
		Assert.assertTrue(c.setFirstName("Joe"));
		Assert.assertTrue(c.setLastName("Mama"));
		Assert.assertTrue(c.setAddress("123 home"));
	}
	@Test
	public void testfnamefalse() {
		Contact c = new Contact("","","","","");
		Assert.assertTrue(c.setContactID("123456789"));
		Assert.assertTrue(c.setPhoneNumber("8161234567"));
		Assert.assertFalse(c.setFirstName("superfragilisticexpealidosous"));
		Assert.assertTrue(c.setLastName("Mama"));
		Assert.assertTrue(c.setAddress("123 home"));
	}
	@Test
	public void testlnamefalse() {
		Contact c = new Contact("","","","","");
		Assert.assertTrue(c.setContactID("123456789"));
		Assert.assertTrue(c.setPhoneNumber("8161234567"));
		Assert.assertTrue(c.setFirstName("Joe"));
		Assert.assertFalse(c.setLastName("superfragilisticexpealidosous"));
		Assert.assertTrue(c.setAddress("123 home"));
	}
	@Test
	public void testaddressfalse() {
		Contact c = new Contact("","","","","");
		Assert.assertTrue(c.setContactID("123456789"));
		Assert.assertTrue(c.setPhoneNumber("8161234567"));
		Assert.assertTrue(c.setFirstName("Joe"));
		Assert.assertTrue(c.setLastName("Mama"));
		Assert.assertFalse(c.setAddress("123 home st drive terrace south"));
	}


}
