package contact;

import java.util.ArrayList;
import java.util.List;

public class ContactService{
	//Initializes new list for contacts
    private List<Contact> contactlist;
    // this creates the array list for the contacts
    public ContactService() {
        contactlist = new ArrayList<Contact>();
    }
    // this will add contacts that fit within the parameter set by the requirements
    public boolean addContact(Contact contact) {
    	
        if (contact == null) {
        	return false;
            //throw new IllegalArgumentException("Contact cannot be null");
        }
        if (contact.getContactID() == null || contact.getContactID().length() > 10) {
        	return false;
            //throw new IllegalArgumentException("Invalid contact ID");
        }
        
        if (contact.getFirstName() == null || contact.getFirstName().length() > 10) {
        	return false;
            //throw new IllegalArgumentException("Invalid first name");
        }

        if (contact.getLastName() == null || contact.getLastName().length() > 10) {
        	return false;
            //throw new IllegalArgumentException("Invalid last name");
        }
       

        if (contact.getPhoneNumber() == null || contact.getPhoneNumber().length() != 10) {
        	return false;
            //throw new IllegalArgumentException("Invalid phone number");
        }
      

        if (contact.getAddress() == null || contact.getAddress().length() > 30) {
        	return false;
            //throw new IllegalArgumentException("Invalid address");
        }

        for (Contact contacts : contactlist) {
            if (contacts.getContactID().equals(contact.getContactID())) {
            	return false;
                //throw new IllegalArgumentException("Contact ID must be unique");
            }
        }

        contactlist.add(contact);
        return true;
    }
    // this will delete a contact with a matching contact id
    public boolean deleteContact(String contactId) {
        for (Contact contact : contactlist) {
            if (contact.getContactID().equals(contactId)) {
            	contactlist.remove(contact);
                return true;
            }
        }
        return false;
        //throw new IllegalArgumentException("Contact not found");
    }
    // this will update a contact based on contact id
    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        for (Contact contact : contactlist) {
            if (contact.getContactID().equals(contactId)) {
                if (firstName != null) {
                    contact.setFirstName(firstName);
                    return true;
                }

                if (lastName != null) {
                    contact.setLastName(lastName);
                    return true;
                }

                if (phone != null) {
                    contact.setPhoneNumber(phone);
                    return true;
                }

                if (address != null) {
                    contact.setAddress(address);
                    return true;
                }
            }
        }
        return false;
        //throw new IllegalArgumentException("Contact not found");
    }
}
