package contact;
//this is the initialization for the contact class
public class Contact {
	private String contactId = "";
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//this is the constructor for the contact class
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		/*
		 if (contactID == null) {
	            throw new IllegalArgumentException("Contact cannot be null");
	        }
	        if (contactID == null || contactID.length() > 10) {
	        	
	            throw new IllegalArgumentException("Invalid contact ID");
	        }
	        
	        if (firstName == null || firstName.length() > 10) {
	            throw new IllegalArgumentException("Invalid first name");
	        }

	        if (lastName == null || lastName.length() > 10) {
	            throw new IllegalArgumentException("Invalid last name");
	        }
	       

	        if (phoneNumber == null || phoneNumber.length() != 10) {
	            //throw new IllegalArgumentException("Invalid phone number");
	        }
	      

	        if (address == null || address.length() > 30) {
	        	
	            throw new IllegalArgumentException("Invalid address");
	        }
   */
		this.contactId = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phoneNumber;
		this.address = address;
	}

	public String getContactID() {
		return contactId;
	}

	public boolean setContactID(String contactID) {
		if (contactID == null || contactID.length() > 10) {
			return false;
            //throw new IllegalArgumentException("Invalid contact ID");
        }
		
		this.contactId = contactID;
		return true;
	}

	public String getFirstName() {
		return firstName;
	}

	public boolean setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			return false;
            //throw new IllegalArgumentException("Invalid first name");
        }
		
		this.firstName = firstName;
		return true;
	}

	public String getLastName() {
		return lastName;
	}

	public boolean setLastName(String lastName) {
		 if (lastName == null || lastName.length() > 10) {
			 return false;
	            //throw new IllegalArgumentException("Invalid last name");
	        }
		this.lastName = lastName;
		return true;
	}

	public String getPhoneNumber() {
		return phone;
	}

	public boolean setPhoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.length() != 10) {
			return false;
            //throw new IllegalArgumentException("Invalid phone number");
        }
		this.phone = phoneNumber;
		return true;
	}

	public String getAddress() {
		return address;
	}

	public boolean setAddress(String address) {
		 if (address == null || address.length() > 30) {
	        	return false;
	            //throw new IllegalArgumentException("Invalid address");
	        }
		this.address = address;
		return true;
	}


}

