package contact;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ContactServiceTest {



	@Test
	public void testAdd() {
		ContactService cs = new ContactService();
		Contact test1 = new Contact("4565156", "Bruce", "Wayne", "0123456789", "Batman 1 Drive");
		Contact test2 = new Contact("4565156", "Ghost", "Buster", "9876543210", "Fire 5 Drive");
		Contact test3 = new Contact("1413", "John", "Hamm", "4444444444444", "Sample 24 Drive");
		
		
		assertEquals(true, cs.addContact(test1));
		assertEquals(false, cs.addContact(test2));
		assertEquals(false, cs.addContact(test3));
	}

	@Test
	public void testDelete() {
		ContactService cs = new ContactService();

		Contact test1 = new Contact("1413252", "Bruce", "Wayne", "0123456789", "Batman 1 Drive");
		Contact test2 = new Contact("1309403",  "Ghost", "Buster", "9876543210", "Fire 5 Drive");
		Contact test3 = new Contact("9752319",  "John", "Hamm", "4444444444", "Sample 24 Drive");

		cs.addContact(test1);
		cs.addContact(test2);
		cs.addContact(test3);

		assertEquals(true, cs.deleteContact("1309403"));
		assertEquals(false, cs.deleteContact("1309404"));
		assertEquals(false, cs.deleteContact("1309403"));
	}

	@Test
	public void testUpdate() {
		ContactService cs = new ContactService();

		Contact test1 = new Contact("1413252", "Bruce", "Wayne", "0123456789", "Batman 1 Drive");
		Contact test2 = new Contact("1309403", "Ghost", "Buster", "9876543210", "Fire 5 Drive");
		Contact test3 = new Contact("9752319", "John", "Hamm", "4444444444", "Sample 24 Drive");

		cs.addContact(test1);
		cs.addContact(test2);
		cs.addContact(test3);

		assertEquals(true, cs.updateContact("9752319", "Jonathan", "hammuel", "1254865483", "hamtown usa"));
		assertEquals(false,cs.updateContact("9752322", "Jonathan", "hammuel", "1254865483", "hamtown usa"));
	}

}